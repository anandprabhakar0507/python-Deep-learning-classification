
.. raw:: html

   <h1 align="center">

 Classification with Python

.. raw:: html

   </h1>

In this notebook we try to practice all the classification algorithms
that we learned in this course.

We load a dataset using Pandas library, and apply the following
algorithms, and find the best one for this specific dataset by accuracy
evaluation methods.

Lets first load required libraries:

.. code:: ipython3

    import itertools
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.ticker import NullFormatter
    import pandas as pd
    import numpy as np
    import matplotlib.ticker as ticker
    from sklearn import preprocessing
    %matplotlib inline

About dataset
~~~~~~~~~~~~~

This dataset is about past loans. The **Loan\_train.csv** data set
includes details of 346 customers whose loan are already paid off or
defaulted. It includes following fields:

+-------------+--------------------------------------------------------------+
| Field       | Description                                                  |
+=============+==============================================================+
| Loan\_statu | Whether a loan is paid off on in collection                  |
| s           |                                                              |
+-------------+--------------------------------------------------------------+
| Principal   | Basic principal loan amount at the                           |
+-------------+--------------------------------------------------------------+
| Terms       | Origination terms which can be weekly (7 days), biweekly,    |
|             | and monthly payoff schedule                                  |
+-------------+--------------------------------------------------------------+
| Effective\_ | When the loan got originated and took effects                |
| date        |                                                              |
+-------------+--------------------------------------------------------------+
| Due\_date   | Since it’s one-time payoff schedule, each loan has one       |
|             | single due date                                              |
+-------------+--------------------------------------------------------------+
| Age         | Age of applicant                                             |
+-------------+--------------------------------------------------------------+
| Education   | Education of applicant                                       |
+-------------+--------------------------------------------------------------+
| Gender      | The gender of applicant                                      |
+-------------+--------------------------------------------------------------+

Lets download the dataset

.. code:: ipython3

    !wget -O loan_train.csv https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0101ENv3/labs/loan_train.csv


.. parsed-literal::

    --2018-12-06 14:00:41--  https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0101ENv3/labs/loan_train.csv
    Resolving s3-api.us-geo.objectstorage.softlayer.net (s3-api.us-geo.objectstorage.softlayer.net)... 67.228.254.193
    Connecting to s3-api.us-geo.objectstorage.softlayer.net (s3-api.us-geo.objectstorage.softlayer.net)|67.228.254.193|:443... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 23101 (23K) [text/csv]
    Saving to: ‘loan_train.csv’
    
    100%[======================================>] 23,101      --.-K/s   in 0.002s  
    
    2018-12-06 14:00:41 (13.4 MB/s) - ‘loan_train.csv’ saved [23101/23101]
    


Load Data From CSV File
~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df = pd.read_csv('loan_train.csv')
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>Unnamed: 0.1</th>
          <th>loan_status</th>
          <th>Principal</th>
          <th>terms</th>
          <th>effective_date</th>
          <th>due_date</th>
          <th>age</th>
          <th>education</th>
          <th>Gender</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>0</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>9/8/2016</td>
          <td>10/7/2016</td>
          <td>45</td>
          <td>High School or Below</td>
          <td>male</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>2</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>9/8/2016</td>
          <td>10/7/2016</td>
          <td>33</td>
          <td>Bechalor</td>
          <td>female</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>3</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>15</td>
          <td>9/8/2016</td>
          <td>9/22/2016</td>
          <td>27</td>
          <td>college</td>
          <td>male</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>4</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>9/9/2016</td>
          <td>10/8/2016</td>
          <td>28</td>
          <td>college</td>
          <td>female</td>
        </tr>
        <tr>
          <th>4</th>
          <td>6</td>
          <td>6</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>9/9/2016</td>
          <td>10/8/2016</td>
          <td>29</td>
          <td>college</td>
          <td>male</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.shape




.. parsed-literal::

    (346, 10)



Convert to date time object
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df['due_date'] = pd.to_datetime(df['due_date'])
    df['effective_date'] = pd.to_datetime(df['effective_date'])
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>Unnamed: 0.1</th>
          <th>loan_status</th>
          <th>Principal</th>
          <th>terms</th>
          <th>effective_date</th>
          <th>due_date</th>
          <th>age</th>
          <th>education</th>
          <th>Gender</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>0</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>45</td>
          <td>High School or Below</td>
          <td>male</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>2</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>33</td>
          <td>Bechalor</td>
          <td>female</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>3</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>15</td>
          <td>2016-09-08</td>
          <td>2016-09-22</td>
          <td>27</td>
          <td>college</td>
          <td>male</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>4</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>28</td>
          <td>college</td>
          <td>female</td>
        </tr>
        <tr>
          <th>4</th>
          <td>6</td>
          <td>6</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>29</td>
          <td>college</td>
          <td>male</td>
        </tr>
      </tbody>
    </table>
    </div>



Data visualization and pre-processing
=====================================

Let’s see how many of each class is in our data set

.. code:: ipython3

    df['loan_status'].value_counts()




.. parsed-literal::

    PAIDOFF       260
    COLLECTION     86
    Name: loan_status, dtype: int64



260 people have paid off the loan on time while 86 have gone into
collection

Lets plot some columns to underestand data better:

.. code:: ipython3

    # notice: installing seaborn might takes a few minutes
    !conda install -c anaconda seaborn -y


.. parsed-literal::

    Solving environment: done
    
    ## Package Plan ##
    
      environment location: /Users/Saeed/anaconda/envs/python3.6
    
      added / updated specs: 
        - seaborn
    
    
    The following packages will be downloaded:
    
        package                    |            build
        ---------------------------|-----------------
        openssl-1.0.2o             |       h26aff7b_0         3.4 MB  anaconda
        ca-certificates-2018.03.07 |                0         124 KB  anaconda
        ------------------------------------------------------------
                                               Total:         3.5 MB
    
    The following packages will be UPDATED:
    
        ca-certificates: 2018.03.07-0      --> 2018.03.07-0      anaconda
        openssl:         1.0.2o-h26aff7b_0 --> 1.0.2o-h26aff7b_0 anaconda
    
    
    Downloading and Extracting Packages
    openssl-1.0.2o       |  3.4 MB | ####################################### | 100% 
    ca-certificates-2018 |  124 KB | ####################################### | 100% 
    Preparing transaction: done
    Verifying transaction: done
    Executing transaction: done


.. code:: ipython3

    import seaborn as sns
    
    bins = np.linspace(df.Principal.min(), df.Principal.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'Principal', bins=bins, ec="k")
    
    g.axes[-1].legend()
    plt.show()



.. image:: output_18_0.png


.. code:: ipython3

    bins = np.linspace(df.age.min(), df.age.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'age', bins=bins, ec="k")
    
    g.axes[-1].legend()
    plt.show()



.. image:: output_19_0.png


Pre-processing: Feature selection/extraction
============================================

Lets look at the day of the week people get the loan
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    df['dayofweek'] = df['effective_date'].dt.dayofweek
    bins = np.linspace(df.dayofweek.min(), df.dayofweek.max(), 10)
    g = sns.FacetGrid(df, col="Gender", hue="loan_status", palette="Set1", col_wrap=2)
    g.map(plt.hist, 'dayofweek', bins=bins, ec="k")
    g.axes[-1].legend()
    plt.show()




.. image:: output_22_0.png


We see that people who get the loan at the end of the week dont pay it
off, so lets use Feature binarization to set a threshold values less
then day 4

.. code:: ipython3

    df['weekend'] = df['dayofweek'].apply(lambda x: 1 if (x>3)  else 0)
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>Unnamed: 0.1</th>
          <th>loan_status</th>
          <th>Principal</th>
          <th>terms</th>
          <th>effective_date</th>
          <th>due_date</th>
          <th>age</th>
          <th>education</th>
          <th>Gender</th>
          <th>dayofweek</th>
          <th>weekend</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>0</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>45</td>
          <td>High School or Below</td>
          <td>male</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>2</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>33</td>
          <td>Bechalor</td>
          <td>female</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>3</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>15</td>
          <td>2016-09-08</td>
          <td>2016-09-22</td>
          <td>27</td>
          <td>college</td>
          <td>male</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>4</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>28</td>
          <td>college</td>
          <td>female</td>
          <td>4</td>
          <td>1</td>
        </tr>
        <tr>
          <th>4</th>
          <td>6</td>
          <td>6</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>29</td>
          <td>college</td>
          <td>male</td>
          <td>4</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



Convert Categorical features to numerical values
------------------------------------------------

Lets look at gender:

.. code:: ipython3

    df.groupby(['Gender'])['loan_status'].value_counts(normalize=True)




.. parsed-literal::

    Gender  loan_status
    female  PAIDOFF        0.865385
            COLLECTION     0.134615
    male    PAIDOFF        0.731293
            COLLECTION     0.268707
    Name: loan_status, dtype: float64



86 % of female pay there loans while only 73 % of males pay there loan

Lets convert male to 0 and female to 1:

.. code:: ipython3

    df['Gender'].replace(to_replace=['male','female'], value=[0,1],inplace=True)
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Unnamed: 0</th>
          <th>Unnamed: 0.1</th>
          <th>loan_status</th>
          <th>Principal</th>
          <th>terms</th>
          <th>effective_date</th>
          <th>due_date</th>
          <th>age</th>
          <th>education</th>
          <th>Gender</th>
          <th>dayofweek</th>
          <th>weekend</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>0</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>45</td>
          <td>High School or Below</td>
          <td>0</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>2</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-08</td>
          <td>2016-10-07</td>
          <td>33</td>
          <td>Bechalor</td>
          <td>1</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>3</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>15</td>
          <td>2016-09-08</td>
          <td>2016-09-22</td>
          <td>27</td>
          <td>college</td>
          <td>0</td>
          <td>3</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>4</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>28</td>
          <td>college</td>
          <td>1</td>
          <td>4</td>
          <td>1</td>
        </tr>
        <tr>
          <th>4</th>
          <td>6</td>
          <td>6</td>
          <td>PAIDOFF</td>
          <td>1000</td>
          <td>30</td>
          <td>2016-09-09</td>
          <td>2016-10-08</td>
          <td>29</td>
          <td>college</td>
          <td>0</td>
          <td>4</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



One Hot Encoding
----------------

How about education?
^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    df.groupby(['education'])['loan_status'].value_counts(normalize=True)




.. parsed-literal::

    education             loan_status
    Bechalor              PAIDOFF        0.750000
                          COLLECTION     0.250000
    High School or Below  PAIDOFF        0.741722
                          COLLECTION     0.258278
    Master or Above       COLLECTION     0.500000
                          PAIDOFF        0.500000
    college               PAIDOFF        0.765101
                          COLLECTION     0.234899
    Name: loan_status, dtype: float64



Feature befor One Hot Encoding
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    df[['Principal','terms','age','Gender','education']].head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Principal</th>
          <th>terms</th>
          <th>age</th>
          <th>Gender</th>
          <th>education</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1000</td>
          <td>30</td>
          <td>45</td>
          <td>0</td>
          <td>High School or Below</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1000</td>
          <td>30</td>
          <td>33</td>
          <td>1</td>
          <td>Bechalor</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1000</td>
          <td>15</td>
          <td>27</td>
          <td>0</td>
          <td>college</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1000</td>
          <td>30</td>
          <td>28</td>
          <td>1</td>
          <td>college</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1000</td>
          <td>30</td>
          <td>29</td>
          <td>0</td>
          <td>college</td>
        </tr>
      </tbody>
    </table>
    </div>



Use one hot encoding technique to conver categorical varables to binary variables and append them to the feature Data Frame
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code:: ipython3

    Feature = df[['Principal','terms','age','Gender','weekend']]
    Feature = pd.concat([Feature,pd.get_dummies(df['education'])], axis=1)
    Feature.drop(['Master or Above'], axis = 1,inplace=True)
    Feature.head()





.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Principal</th>
          <th>terms</th>
          <th>age</th>
          <th>Gender</th>
          <th>weekend</th>
          <th>Bechalor</th>
          <th>High School or Below</th>
          <th>college</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1000</td>
          <td>30</td>
          <td>45</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1000</td>
          <td>30</td>
          <td>33</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1000</td>
          <td>15</td>
          <td>27</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1000</td>
          <td>30</td>
          <td>28</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1000</td>
          <td>30</td>
          <td>29</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



Feature selection
~~~~~~~~~~~~~~~~~

Lets defind feature sets, X:

.. code:: ipython3

    X = Feature
    X[0:5]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Principal</th>
          <th>terms</th>
          <th>age</th>
          <th>Gender</th>
          <th>weekend</th>
          <th>Bechalor</th>
          <th>High School or Below</th>
          <th>college</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1000</td>
          <td>30</td>
          <td>45</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1000</td>
          <td>30</td>
          <td>33</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1000</td>
          <td>15</td>
          <td>27</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1000</td>
          <td>30</td>
          <td>28</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1000</td>
          <td>30</td>
          <td>29</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
      </tbody>
    </table>
    </div>



What are our lables?

.. code:: ipython3

    y = df['loan_status'].values
    y[0:5]




.. parsed-literal::

    array(['PAIDOFF', 'PAIDOFF', 'PAIDOFF', 'PAIDOFF', 'PAIDOFF'], dtype=object)



Normalize Data
--------------

Data Standardization give data zero mean and unit variance (technically
should be done after train test split )

.. code:: ipython3

    X= preprocessing.StandardScaler().fit(X).transform(X)
    X[0:5]




.. parsed-literal::

    array([[ 0.51578458,  0.92071769,  2.33152555, -0.42056004, -1.20577805,
            -0.38170062,  1.13639374, -0.86968108],
           [ 0.51578458,  0.92071769,  0.34170148,  2.37778177, -1.20577805,
             2.61985426, -0.87997669, -0.86968108],
           [ 0.51578458, -0.95911111, -0.65321055, -0.42056004, -1.20577805,
            -0.38170062, -0.87997669,  1.14984679],
           [ 0.51578458,  0.92071769, -0.48739188,  2.37778177,  0.82934003,
            -0.38170062, -0.87997669,  1.14984679],
           [ 0.51578458,  0.92071769, -0.3215732 , -0.42056004,  0.82934003,
            -0.38170062, -0.87997669,  1.14984679]])



Classification
==============

Now, it is your turn, use the training set to build an accurate model.
Then use the test set to report the accuracy of the model You should use
the following algorithm: - K Nearest Neighbor(KNN) - Decision Tree -
Support Vector Machine - Logistic Regression

\_\_ Notice:\_\_ - You can go above and change the pre-processing,
feature selection, feature-extraction, and so on, to make a better
model. - You should use either scikit-learn, Scipy or Numpy libraries
for developing the classification algorithms. - You should include the
code of the algorithm in the following cells.

K Nearest Neighbor(KNN)
=======================

| Notice: You should find the best k to build the model with the best
  accuracy.
| **warning:** You should not use the **loan\_test.csv** for finding the
  best k, however, you can split your train\_loan.csv into train and
  test to find the best **k**.

Decision Tree
=============

Support Vector Machine
======================

Logistic Regression
===================

Model Evaluation using Test set
===============================

.. code:: ipython3

    from sklearn.metrics import jaccard_similarity_score
    from sklearn.metrics import f1_score
    from sklearn.metrics import log_loss

First, download and load the test set:

.. code:: ipython3

    !wget -O loan_test.csv https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/ML0101ENv3/labs/loan_test.csv

Load Test set for evaluation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code:: ipython3

    test_df = pd.read_csv('loan_test.csv')
    test_df.head()

Report
======

You should be able to report the accuracy of the built model using
different evaluation metrics:

+----------------------+-----------+------------+-----------+
| Algorithm            | Jaccard   | F1-score   | LogLoss   |
+======================+===========+============+===========+
| KNN                  | ?         | ?          | NA        |
+----------------------+-----------+------------+-----------+
| Decision Tree        | ?         | ?          | NA        |
+----------------------+-----------+------------+-----------+
| SVM                  | ?         | ?          | NA        |
+----------------------+-----------+------------+-----------+
| LogisticRegression   | ?         | ?          | ?         |
+----------------------+-----------+------------+-----------+

Want to learn more?
-------------------

IBM SPSS Modeler is a comprehensive analytics platform that has many
machine learning algorithms. It has been designed to bring predictive
intelligence to decisions made by individuals, by groups, by systems –
by your enterprise as a whole. A free trial is available through this
course, available here: `SPSS
Modeler <http://cocl.us/ML0101EN-SPSSModeler>`__.

Also, you can use Watson Studio to run these notebooks faster with
bigger datasets. Watson Studio is IBM's leading cloud solution for data
scientists, built by data scientists. With Jupyter notebooks, RStudio,
Apache Spark and popular libraries pre-packaged in the cloud, Watson
Studio enables data scientists to collaborate on their projects without
having to install anything. Join the fast-growing community of Watson
Studio users today with a free account at `Watson
Studio <https://cocl.us/ML0101EN_DSX>`__

.. raw:: html

   <hr>

Copyright © 2018 `Cognitive Class <https://cocl.us/DX0108EN_CC>`__. This
notebook and its source code are released under the terms of the `MIT
License <https://bigdatauniversity.com/mit-license/>`__.​

Thanks for completing this lesson!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Notebook created by: Saeed Aghabozorgi
